<?php
/**
 * Template Name: Test
 */


 get_header(); // Incluir el encabezado de WordPress

 get_footer(); // Incluir el pie de página de WordPress

?>