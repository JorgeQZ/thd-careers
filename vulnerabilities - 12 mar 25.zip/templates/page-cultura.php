<?php
/**
 * Template Name: Cultura
 */
get_header(); ?>
<main>
    <?php
    the_content();

    // echo '<pre>';
    // print_r(get_field('item_1', 'options'));
    // print_r(get_field('item_2', 'options'));
    // print_r(get_field('item_3', 'options'));
    // print_r(get_field('item_4', 'options'));
    // print_r(get_field('item_5', 'options'));
    // print_r(get_field('item_6', 'options'));
    // print_r(get_field('item_7', 'options'));
    // print_r(get_field('item_8', 'options'));
    // echo '</pre>'
    ?>
</main>
<?php get_footer(); ?>